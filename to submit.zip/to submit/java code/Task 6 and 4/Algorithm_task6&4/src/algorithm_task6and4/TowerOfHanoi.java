/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm_task6and4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Neema
 */
public class TowerOfHanoi {

    
    
    static int counter=0;
    static int steps=0;
    static int call= 0 ; 
    static int k= 0 ;
    static List<String> list=new ArrayList<String>();  
    
    public TowerOfHanoi() {
    
    }
    
    
    
    

    
    static void towerOfHanoi_3towers(int n, char from_rod, char to_rod, char aux_rod)
    { 
            steps++;
        if (n==k)
            return;
  
            towerOfHanoi_3towers(n-1, from_rod, aux_rod, to_rod);
            System.out.println("Move disk " + (n) + " from rod " +  from_rod + "_source to rod " + to_rod);
            steps++;
            counter++;
            towerOfHanoi_3towers(n-1, aux_rod, to_rod, from_rod);       
    }

    static void towerOfHanoi(int n, char from_rod,char to_rod, char aux_rod1, char aux_rod2)
{
     
 
        if (n==0)
            return;
        if (n == 1){
              System.out.println("Move disk "+ n+ " from rod "+from_rod+ "_source to rod "+ to_rod);
              return;
        }
       
     
        towerOfHanoi(n - 2, from_rod, aux_rod1, aux_rod2, to_rod);
        steps++;
        System.out.println("Move disk " + (n-1) + " from rod " + from_rod + "_source to rod " + aux_rod2);
        list.add("Move disk " + (n-1) + " from rod " + from_rod + "_source to rod " + aux_rod2);
        counter++;
        steps++;
        System.out.println("Move disk " + (n) + " from rod " + from_rod +"_source to rod " + to_rod);
        list.add("Move disk " + (n) + " from rod " + from_rod +"_source to rod " + to_rod);
        counter++;
        steps++;
        System.out.println("Move disk " + (n-1) +" from rod " + aux_rod2 + "_source to rod " + to_rod);
        
        list.add("Move disk " + (n-1) +" from rod " + aux_rod2 + "_source to rod " + to_rod);
        counter++;
        towerOfHanoi(n - 2, aux_rod1, to_rod, from_rod, aux_rod2);
}
      public static  void solve()
    {
        list.clear(); 
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the number of disks: ");
        int n = sc.nextInt(); // Number of disks
        
        
        k= n/2;
        // A, B, C and D are names of rods
        towerOfHanoi(n/2, 'A', 'D', 'B', 'C'); 
        System.out.println("The number of moves needed to move the top 4 disks from A to D is: "+counter);
        towerOfHanoi_3towers(n, 'A', 'C', 'B');  // A, B and C are names of rods
        System.out.println("The number of moves needed to move the lowest 4 disks from A to C is: "+counter);
          
       // towerOfHanoi(n, 'D', 'C', 'B', 'A');     //instead of calling, we use the result of the last call
        //   System.out.println(counter);
   
       for (int i=0;i <list.size();i++)
        {
             String a= list.get(i).replace("A_source", "d_source");
             a = a.replace(" A"," d");
             a= a.replace("D_source","c_source" );
             a=a.replace(" D", " c");
             a= a.replace("C_source","A_source" );
             a=a.replace(" C", " A");
             a=a.replace(" d", " D");
             a=a.replace(" c", " C");
             a=a.replace("c_source", "C_source");
             a=a.replace("d_source", "D_source");
             System.out.println(a);
             counter++;
       
       
        }
       System.out.println("Total Number of moves after moving the top 4 disks from D to C is: "+counter);
       counter=0;
    }
    
}
