package algorithm_task6and4;

import java.util.Scanner;

public class Algorithm_task6and4 {
   

    public static void main(String[] args) {
       
       Scanner sc = new Scanner(System.in);
       System.out.println("enter a problem number or 0 to exit: ");
       int choice = sc.nextInt();
       while(choice!=0)
       {
       
         
           if (choice == 6)
           {
              TowerOfHanoi.solve();
           }
           else if(choice == 4)
           {
               System.out.println("1-Brute Force  2-Greedy ");
               choice = sc.nextInt();
               if (choice==1)
               {
                   Pennies_BruteForce.solve();
               }
               else if (choice==2)
               {
                   Pennies_problem.solve();
               }
           }
           
          System.out.println("enter a problem number or 0 to exit: ");
          choice = sc.nextInt();
          
    }
      // Pennies_BruteForce.solve();

    }
}
