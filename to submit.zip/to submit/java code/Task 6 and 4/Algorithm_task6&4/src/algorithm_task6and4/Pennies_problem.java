/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithm_task6and4;

import java.util.Scanner;

/**
 *
 * @author Neema
 */
public class Pennies_problem {
    static int pennies ,  boxes_no, counter=1;
   

     
    public Pennies_problem()
    {
        
    }
    
    public static void  function(int b)
    {
        pennies = b  ;
        boxes_no = (int)(Math.ceil( log2(pennies + 1) ));
        int[] array = new int[boxes_no]; 
      
        for (int i = 1; i < boxes_no ; i++)
        {
            array[i] = 0;
	}
        array[0] = pennies;
        System.out.print( "Iteration number " + (counter ) + ": ");
         counter++;
        for (int j = 0; j < boxes_no; j++)
                {
                    System.out.print(array[j] + " ");
                }
                System.out.print("\n");
        for (int i = 0 ; i < boxes_no -1  ; i++)
	{
            array[i + 1] = array[i] / 2;
            array[i] = array[i] % 2;
            System.out.print( "Iteration number " + (counter) + ": ");
            counter++;

            
            for (int j = 0; j < boxes_no; j++)
            {
                System.out.print(array[j] + " ");
            }
            System.out.print("\n");
	}
        counter=1;
    }
    public static double log2(int N)
        {
            double result = (Math.log(N) / Math.log(2));
            return result;
        }
    
    public static  void solve(){
         int b , x;
        boolean input = true;
        Scanner sc = new Scanner(System.in); 
    
        System.out.print("please, enter the number of pennies: ");
        b = sc.nextInt();  
        function(b);
          
            

     
    }
    
    
  
    
    
}
