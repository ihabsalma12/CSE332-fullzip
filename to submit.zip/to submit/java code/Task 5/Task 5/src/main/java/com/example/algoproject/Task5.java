package com.example.algoproject;

import java.util.Arrays;

public class Task5 {
    static int counter = 0;

    public static void display(boolean[] switches){
        System.out.println("Step "+counter+":");
        for (boolean s: switches) {
            if (s)
                System.out.print(1+"  ");
            else
                System.out.print(0+"  ");
        }
        System.out.println();
    }
    public static void switchOn(boolean[] switches, int n){
        int size = switches.length;
        if (n == 1){
            switches[size - 1] = true;
            counter++;
            display(switches);
        }else if (n == 2){
            switches[size - 1] = true;
            counter++;
            display(switches);
            switches[size - 2] = true;
            counter++;
            display(switches);
        }else {
            switchOn(switches, n - 1);
            switchOff(switches, n - 2);
            switches[size - n] = true;
            counter++;
            display(switches);
            switchOn(switches, n - 2);
        }
    }
    public static void switchOff(boolean[] switches, int n){
        int size = switches.length;
        if (n == 1){
            switches[size - 1] = false;
            counter++;
            display(switches);
        }else if (n == 2){
            switches[size - 2] = false;
            counter++;
            display(switches);
            switches[size - 1] = false;
            counter++;
            display(switches);
        }else{
            switchOff(switches, n - 2);
            switches[size - n] = false;
            counter++;
            display(switches);
            switchOn(switches, n - 2);
            switchOff(switches, n - 1);
        }
    }
    public static void solution(int n){
        if (n == 0)
            return;
        boolean[] switches = new boolean[n];
        Arrays.fill(switches, true);

        System.out.println("Initial State:");
        for (boolean s: switches) {
            if (s)
                System.out.print(1+"  ");
            else
                System.out.print(0+"  ");
        }
        System.out.println();

        switchOff(switches, n);
        System.out.println();
        System.out.println("Minimum number of moves: "+counter);

    }
    public static void main(String[] args){

        solution(10);
    }
}
