package com.example.algoproject;

import static java.lang.Math.*;

public class Task5SecondAlgorithmForComparison {

    public static String decToBinary(int deciNum, int size) {
        String binaryNum = "";
        while (deciNum > 0){
            binaryNum = Integer.toString(deciNum % 2)+binaryNum;
            deciNum = deciNum / 2;
        }
        while (binaryNum.length() < size){
            binaryNum = "0"+binaryNum;
        }
        return binaryNum;
    }

    public static void generateGrayCode(int n){
        int minNumberOfMoves;
        if (n <= 0) {
            return;
        }

        if (n % 2 == 0)
            minNumberOfMoves = (int) ((pow(2, n+1) - 2)/3);
        else
            minNumberOfMoves = (int) ((pow(2, n+1) - 1)/3);

        int[] grayCode = new int[n];
        for (int i = minNumberOfMoves - 1; i >= 0; i--){
            String binaryCode = decToBinary(i, n);
            if (binaryCode.charAt(0) == '0')
                grayCode[0] = 0;
            else
                grayCode[0] = 1;
            for (int j=1; j<n; j++){
                if (binaryCode.charAt(j) != binaryCode.charAt(j-1)){
                    grayCode[j] = 1;
                }else{
                    grayCode[j] = 0;
                }
            }

            for (int k = 0; k<n; k++){
                System.out.print(grayCode[k]+" ");
            }
            System.out.println();
        }
        System.out.println("Calculated is "+ minNumberOfMoves);
    }
    public static void main (String[] args){
        generateGrayCode(10);

    }
}
