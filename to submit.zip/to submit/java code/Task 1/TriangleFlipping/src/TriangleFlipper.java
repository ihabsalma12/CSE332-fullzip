
import java.util.ArrayList;
import java.util.List;

public class TriangleFlipper {

	private List<List<Character>> triangle = new ArrayList<List<Character>>();
	private int totalMoves = 0;
	private int triangleVerticalSize;
	private int triangleHorizontalSize;
	private int trianglePreviousApexRow;
	private int newTriangleApexRow;
	private int triangleBaseRow;
	private int triangleBaseSize;
	private String triangleBasePlace;
	private String trianglePreviousApexPlace;
	private String newTriangleApexPlace;
	private String triangleBaseSizeType;

	public TriangleFlipper(List<List<Character>> triangle) {
		this.triangle = triangle;
		triangleVerticalSize = triangle.size();
		triangleHorizontalSize = triangle.get(0).size();
		getTriangleBaseSizeAndPlace();
		getTriangleBaseAndApexRow();
		getTriangleBaseSizeType();
	}

	private void getTriangleBaseSizeType() {
		if (triangleBaseSize % 2 == 0) {
			triangleBaseSizeType = "even";
		} else {
			triangleBaseSizeType = "odd";
		}
	}

	private void getTriangleBaseSizeAndPlace() {

		for (int i = 0; i < triangleHorizontalSize; i++) {
			/* triangle.get(1) to skip the upper empty row */
			if (triangle.get(1).get(i) == 'O')
				triangleBaseSize++;
		}
		triangleBasePlace = "top";
		trianglePreviousApexPlace = "bottom";

		if (triangleBaseSize == 1) /* It will = 1 if the triangle base is on bottom */
		{
			triangleBaseSize = 0;

			for (int i = 0; i < triangleHorizontalSize; i++) {
				/* triangle[triangle.size() - 2] to skip the lower empty row */
				if (triangle.get(triangle.size() - 2).get(i) == 'O')
					triangleBaseSize++;
			}
			triangleBasePlace = "bottom";
			trianglePreviousApexPlace = "top";
		}

		newTriangleApexPlace = triangleBasePlace;

	}

	private void getTriangleBaseAndApexRow() {
		if (triangleBasePlace == "top") {
			triangleBaseRow = 1;
			trianglePreviousApexRow = triangleVerticalSize - 2;
		} else {
			triangleBaseRow = triangleVerticalSize - 2;
			trianglePreviousApexRow = 1;
		}
	}

	
	/*Iterative improvement functions*/
	
	private void moveCircleToMirroredTarget(int i_index, int j_index) {
		int mirrorIndex;
		int lastCircleOnPath_i_index;
		if (triangleBaseSizeType == "odd") {
			mirrorIndex = triangleVerticalSize - i_index - 1;
		}

		else {
			if (newTriangleApexPlace == "top") {
				mirrorIndex = triangleVerticalSize - i_index - 2;
			} 
			else {
				mirrorIndex = triangleVerticalSize - i_index;
			}
		}
		
		lastCircleOnPath_i_index = getLastCircleIndexOnMovingPath(i_index,j_index,mirrorIndex);
		
		/*if no circle on the moving path*/
		if (lastCircleOnPath_i_index == -1)
		{
			triangle.get(i_index).set(j_index, '-');
			triangle.get(mirrorIndex).set(j_index, 'O');
			totalMoves++;
			System.out.print("move number: " + totalMoves + "\n");
			printCircles();
		}
		
		/*there is a circle on the moving path*/
		else
		{
			triangle.get(lastCircleOnPath_i_index).set(j_index, '-');
			triangle.get(mirrorIndex).set(j_index, 'O');
			totalMoves++;
			System.out.print("move number: " + totalMoves + "\n");
			printCircles();
			shiftCirclesOnThePathByTwoSteps(lastCircleOnPath_i_index , j_index,i_index);
			
		}

	}
	
	private void shiftCirclesOnThePathByTwoSteps(int i_index, int j_index,int i_toStopIndex)
	{
		if (i_toStopIndex > i_index)
		{
			for(int i = i_index+1; i <= i_toStopIndex; i++)
			{
				if(triangle.get(i).get(j_index) == 'O')
				{
					triangle.get(i).set(j_index, '-');
					triangle.get(i-2).set(j_index, 'O');
					totalMoves++;
					System.out.print("move number: " + totalMoves + "\n");
					printCircles();
				}
			}
		}
		else
		{
			for(int i = i_index-1; i >= i_toStopIndex; i--)
			{
				if(triangle.get(i).get(j_index) == 'O')
				{
					triangle.get(i).set(j_index, '-');
					triangle.get(i+2).set(j_index, 'O');
					totalMoves++;
					System.out.print("move number: " + totalMoves + "\n");
					printCircles();
				}
			}
		}
	}
	
	
	private int getLastCircleIndexOnMovingPath(int i_index, int j_index, int i_target)
	{
		int circleOnPath_i_index = -1;
		

		if (i_target > i_index)
		{
			for(int i = i_index+1;i <= i_target;i++)
			{
				if(triangle.get(i).get(j_index) == 'O' )
				{
					circleOnPath_i_index = i;
				}
			}
		}
		else
		{
			for(int i = i_index-1;i >= i_target;i--)
			{
				if(triangle.get(i).get(j_index) == 'O' )
				{
					circleOnPath_i_index = i;
				}
			}
		}

		return circleOnPath_i_index;

	}
	

	private int calculateRowCircles(int row) {
		int size = 0;
		for (int i = 0; i < triangleHorizontalSize; i++) {
			if (triangle.get(row).get(i) == 'O')
				size++;
		}
		return size;
	}

	private void moveRowAdditionalCircles(int row, int numberOfCirclesToBeRemoved) {
		boolean moveFromLeft = true;
		int movesCounter = 0;
		int i = 0;
		int j = triangleHorizontalSize-1;
		
		while (movesCounter != numberOfCirclesToBeRemoved) {
			if (moveFromLeft) {
				for (  ; i < triangleHorizontalSize/2; i++) {
					if (triangle.get(row).get(i) == 'O') {
						moveCircleToMirroredTarget(row, i);
						movesCounter++;
						break;
					}
				}

			} else {
				for ( ; j >= triangleHorizontalSize/2; j--) {
					if (triangle.get(row).get(j) == 'O') {
						moveCircleToMirroredTarget(row, j);
						movesCounter++;
						break;
					}
				}
			}
			moveFromLeft = !moveFromLeft;
		}
	}

	private void moveApexCircle() {
		if (triangleBaseSizeType == "odd") {
			newTriangleApexRow = triangleBaseRow;

		} else {
			if (trianglePreviousApexPlace == "top") {
				newTriangleApexRow = triangleVerticalSize - 1;

			} else {
				newTriangleApexRow = 0;

			}
			
			if(triangleBaseSizeType == "odd")
			{
				triangle.get(newTriangleApexRow).set((triangleHorizontalSize / 2), 'O');
				triangle.get(trianglePreviousApexRow).set((triangleHorizontalSize / 2), '-');
				totalMoves++;
				System.out.print("move number: " + totalMoves + "\n");
				printCircles();
			}
			else
			{
				if (trianglePreviousApexPlace == "top")
				{
					shiftCirclesOnThePathByTwoSteps(triangleBaseRow+1, (triangleHorizontalSize/2), 1);
				}
				else
				{
					shiftCirclesOnThePathByTwoSteps(triangleBaseRow-1, (triangleHorizontalSize/2), trianglePreviousApexRow);
				}
			}
		}
	}

	private void printCircles() {
		for (int i = 0; i < triangleVerticalSize; i++) {
			for (int j = 0; j < triangleHorizontalSize; j++) {
				System.out.print(triangle.get(i).get(j) + " ");
			}
			System.out.print("\n");

		}

		System.out.print("*******************************************\n");
	}

	public void flip() {

		System.out.print("before flipping: \n");

		printCircles();

		moveApexCircle();

		/* Iterative improvement */

		int rowCircles;
		int nextRowCircles;
		int numberOfCirclesToBeRemoved;

		if (newTriangleApexPlace == "bottom") {
			for (int row = triangleVerticalSize - 1; row > triangleVerticalSize/2; row--) {
				rowCircles = calculateRowCircles(row);
				nextRowCircles = calculateRowCircles(row - 1);

				if (rowCircles != (nextRowCircles - 1)) {
					numberOfCirclesToBeRemoved = nextRowCircles - (rowCircles + 1);
					moveRowAdditionalCircles(row - 1, numberOfCirclesToBeRemoved);
				}
			}
		}

		if (newTriangleApexPlace == "top") {
			for (int row = 0; row < triangleVerticalSize /2; row++) {
				rowCircles = calculateRowCircles(row);
				nextRowCircles = calculateRowCircles(row + 1);

				if (rowCircles != (nextRowCircles - 1)) {
					numberOfCirclesToBeRemoved = nextRowCircles - (rowCircles + 1);
					moveRowAdditionalCircles(row + 1, numberOfCirclesToBeRemoved);
				}
			}
		}

		System.out.print("Flipped successfully with total number of moves = " + totalMoves + "\n");

}

	
/*Brute force algorithm implementation using recursion*/

	public void bruteForceRecursionFlip()
{
	int targetRow;
	replaceAllCriclesWithX();
	System.out.print("before flipping: \n");
	printCircles();
	
	for (int column = 0; column < triangleHorizontalSize; column++)
	{
		for(int row = 0; row < triangleVerticalSize; row++)
		{
			if(triangle.get(row).get(column) == 'x')
			{
				targetRow = triangleVerticalSize-1 -row;
				
				if (triangle.get(targetRow).get(column) == 'O'|| triangle.get(targetRow).get(column) == 'x')
				{
					triangle.get(targetRow).set(column,'O');
					triangle.get(row).set(column,'O');
					
				}
				else
				{
					recursionBrutForceMoveCircleOnPath(row,column,targetRow);
				}
				
			}
		}
	}
	System.out.print("Flipped successfully with total number of moves = " + totalMoves + "\n");
}

	private void recursionBrutForceMoveCircleOnPath(int row, int column, int targetRow)
{
	int newTargetRow = -1;
	char previousCircleState = 'O';

	if (row < targetRow)
	{
		for (int i = row+1; i <= targetRow; i++)
		{
			if(triangle.get(i).get(column) == 'O' || triangle.get(i).get(column) == 'x')
			{
				newTargetRow = i;
				previousCircleState = triangle.get(i).get(column);
				recursionBrutForceMoveCircleOnPath(i,column,targetRow);
				break;
			}
		}
	}
	else if (row > targetRow)
	{
		for (int i = row-1; i >= targetRow; i--)
		{
			if(triangle.get(i).get(column) == 'O' || triangle.get(i).get(column) == 'x')
			{
				newTargetRow = i;
				recursionBrutForceMoveCircleOnPath(i,column,targetRow);
				break;
			}
		}
	}
	


		triangle.get(row).set(column, '-');
		if (newTargetRow == -1)
		{
			triangle.get(targetRow).set(column, 'O');
		}
		else
		{
			triangle.get(newTargetRow).set(column, previousCircleState);
		}
		totalMoves++;
		System.out.print("move number: " + totalMoves + "\n");
		printCircles();


	
}

	private void replaceAllCriclesWithX()
{
	for (int i = 0; i < triangleVerticalSize; i++)
	{
		for(int j = 0; j<triangleHorizontalSize;j++)
		{
			if(triangle.get(i).get(j) == 'O')
			{
				triangle.get(i).set(j,'x') ;
			}
		}
	}
}


}

