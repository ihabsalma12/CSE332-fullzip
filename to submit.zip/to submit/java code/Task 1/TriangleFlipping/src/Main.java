import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		List<List<Character>> triangle_testcase1 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-'),
		                Arrays.asList('-','O','-'),
		                Arrays.asList('O','-','O'),
		                Arrays.asList('-','-','-')
		                )
		                
				);
		
		List<List<Character>> triangle_testcase2 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-'),
		                Arrays.asList('-','-','O','-','-'),
		                Arrays.asList('-','O','-','O','-'),
		                Arrays.asList('O','-','O','-','O'),
		                Arrays.asList('-','-','-','-','-')
		                )
		                
				);
		
		List<List<Character>> triangle_testcase3 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-'),
		                Arrays.asList('O','-','O','-','O'),
		                Arrays.asList('-','O','-','O','-'),
		                Arrays.asList('-','-','O','-','-'),
		                Arrays.asList('-','-','-','-','-')
		                )
		                
				);
		

		
		List<List<Character>> triangle_testcase4 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','O','-','-','-','-'),
		                Arrays.asList('-','-','-','O','-','O','-','-','-'),
		                Arrays.asList('-','-','O','-','O','-','O','-','-'),
		                Arrays.asList('-','O','-','O','-','O','-','O','-'),
		                Arrays.asList('O','-','O','-','O','-','O','-','O'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-')
		                )
		                
				);
		
		List<List<Character>> triangle_testcase5 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','O','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','O','-','O','-','-','-','-'),
		                Arrays.asList('-','-','-','O','-','O','-','O','-','-','-'),
		                Arrays.asList('-','-','O','-','O','-','O','-','O','-','-'),
		                Arrays.asList('-','O','-','O','-','O','-','O','-','O','-'),
		                Arrays.asList('O','-','O','-','O','-','O','-','O','-','O'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-')
		                )
		                
				);
		
		
		List<List<Character>> triangle_testcase6 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','O','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','O','-','O','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','O','-','O','-','O','-','-','-','-'),
		                Arrays.asList('-','-','-','O','-','O','-','O','-','O','-','-','-'),
		                Arrays.asList('-','-','O','-','O','-','O','-','O','-','O','-','-'),
		                Arrays.asList('-','O','-','O','-','O','-','O','-','O','-','O','-'),
		                Arrays.asList('O','-','O','-','O','-','O','-','O','-','O','-','O'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-')
		                )
		                
				);
		
		
		List<List<Character>> triangle_testcase7 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('O','-','O','-','O','-','O','-','O','-','O','-','O'),
		                Arrays.asList('-','O','-','O','-','O','-','O','-','O','-','O','-'),
		                Arrays.asList('-','-','O','-','O','-','O','-','O','-','O','-','-'),
		                Arrays.asList('-','-','-','O','-','O','-','O','-','O','-','-','-'),
		                Arrays.asList('-','-','-','-','O','-','O','-','O','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','O','-','O','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','O','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-')
		                )
		                
				);
		
		
		
		
		
		
		
		List<List<Character>> triangle_testcase8 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','O','-','-','-'),
		                Arrays.asList('-','-','O','-','O','-','-'),
		                Arrays.asList('-','O','-','O','-','O','-'),
		                Arrays.asList('O','-','O','-','O','-','O'),
		                Arrays.asList('-','-','-','-','-','-','-')
		                )
		                
				);
		
		List<List<Character>> triangle_testcase9 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','O','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','O','-','O','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','O','-','O','-','O','-','-','-','-'),
		                Arrays.asList('-','-','-','O','-','O','-','O','-','O','-','-','-'),
		                Arrays.asList('-','-','O','-','O','-','O','-','O','-','O','-','-'),
		                Arrays.asList('-','O','-','O','-','O','-','O','-','O','-','O','-'),
		                Arrays.asList('O','-','O','-','O','-','O','-','O','-','O','-','O'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-')
		                )
		                
				);
		
		
		
		
		
		List<List<Character>> triangle_testcase10 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','O','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','O','-','O','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','O','-','O','-','O','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','O','-','O','-','O','-','O','-','-','-','-'),
		                Arrays.asList('-','-','-','O','-','O','-','O','-','O','-','O','-','-','-'),
		                Arrays.asList('-','-','O','-','O','-','O','-','O','-','O','-','O','-','-'),
		                Arrays.asList('-','O','-','O','-','O','-','O','-','O','-','O','-','O','-'),
		                Arrays.asList('O','-','O','-','O','-','O','-','O','-','O','-','O','-','O'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-','-','-')
		                )
		                
				);
		
		List<List<Character>> triangle_testcase11 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','O','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','-','O','-','O','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','O','-','O','-','O','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','O','-','O','-','O','-','O','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','O','-','O','-','O','-','O','-','O','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','O','-','O','-','O','-','O','-','O','-','O','-','-','-','-'),
		                Arrays.asList('-','-','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','-','-'),
		                Arrays.asList('-','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','-'),
		                Arrays.asList('-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-'),
		                Arrays.asList('O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-')
		                )
		                
				);
		
		
		List<List<Character>> triangle_testcase12 = new ArrayList<List<Character>>(
				Arrays.asList(
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','O','-','-','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','O','-','O','-','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','O','-','O','-','O','-','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','-','O','-','O','-','O','-','O','-','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','-','O','-','O','-','O','-','O','-','O','-','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','-','O','-','O','-','O','-','O','-','O','-','O','-','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','-','-','-','-'),
		                Arrays.asList('-','-','-','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','-','-','-'),
		                Arrays.asList('-','-','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','-','-'),
		                Arrays.asList('-','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','-'),
		                Arrays.asList('-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-'),
		                Arrays.asList('O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O','-','O'),
		                Arrays.asList('-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-')
		                )
				);
		
		
	
		
		/*Change the triangle_testcase8 from 8 to any another number in range 1 to 12 to view the test cases*/
		TriangleFlipper flipper = new TriangleFlipper(triangle_testcase8);
		
		
		/*Iterative improvement*/
		flipper.flip();
		
		/*Brute force algorithm, use this code and comment the flipper.flip()*/
		//flipper.bruteForceRecursionFlip();
		

		
	}

}
