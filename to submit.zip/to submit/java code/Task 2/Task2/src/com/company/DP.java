package com.company;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class DP {
    class Move implements Comparable<Move> {
        int OldPos, NewPos;
        int hole;

        public Move(int oldPos, int newPos, int hole) {
            OldPos = oldPos;
            NewPos = newPos;
            this.hole = hole;
        }

        @Override
        public String toString() {
            return "Move{" +
                    "OldPos=" + OldPos +
                    ", NewPos=" + NewPos +
                    ", hole=" + hole +
                    '}';
        }

        @Override
        //To sort all possible moves where the closer pegs to the hole have higher priority
        public int compareTo(Move move) {
            return Integer.valueOf(this.OldPos).compareTo(Integer.valueOf(move.OldPos));
        }
    }

    Integer[] Board;
    ArrayList<Move> MovesList;
    ArrayList<Integer[]> Unsuccessfull_Board;

    public DP(Integer[] board) {
        Board = board;
        MovesList = new ArrayList<>();
        Unsuccessfull_Board = new ArrayList<Integer[]>();
    }

    private void PrintMoves() {
        for (Move m : MovesList) {
            System.out.println(m.toString());
        }
    }

    private void DisplayGrid() {
        for (int i : Board) {
            System.out.print(Integer.toString(i) + " ");
        }
        System.out.println(" ");
    }

    private void MakeMove(Move move) {
        Board[move.OldPos] = 0;
        Board[move.NewPos] = 1;
        Board[move.hole] = 0;
        MovesList.add(move);
    }

    private void RemoveMove(Move move) {
        Board[move.OldPos] = 1;
        Board[move.NewPos] = 0;
        Board[move.hole] = 1;
        MovesList.remove(MovesList.size() - 1);
    }

    private ArrayList<Move> ComputePossibilities() {
        ArrayList<Move> PossibleMoves = new ArrayList<>();
        //A possible move exists when there are two pegs just before or after a hole
        for (int i = 0; i < Board.length; i++) {
            if (Board[i] == 0) {
                if (i - 2 >= 0) {
                    //For right jumps
                    if (Board[i - 2] == 1 && Board[i - 1] == 1) {
                        PossibleMoves.add(new Move((i - 2), i, (i - 1)));
                    }
                }
                //For left jumps
                if (i + 2 < Board.length) {
                    if (Board[i + 2] == 1 && Board[i + 1] == 1) {
                        PossibleMoves.add(new Move((i + 2), i, (i + 1)));
                    }
                }
            }
        }
        return PossibleMoves;
    }


    private int CountPegs() {
        int Count = 0;
        for (int i = 0; i < Board.length; i++) {
            if (Board[i] == 1) {
                Count++;
            }
        }
        return Count;
    }

    public boolean Solve() {
        if (Unsuccessfull_Board.contains(Board)) {
                return false;

        }

        if (CountPegs() == 1) {
            DisplayGrid();
            PrintMoves();
            return true;

        } else {
            ArrayList<Move> PossibleMoves = ComputePossibilities();
            Collections.sort(PossibleMoves);
            for (Move move : PossibleMoves) {
                MakeMove(move);
                // backward recursive call
                if (Solve()) {
                    return true;
                } else {
                    RemoveMove(move);
                }
            }
            if (!Unsuccessfull_Board.contains(Board)) {
                Unsuccessfull_Board.add(Board);
            }
//        for (Integer i[] : Unsuccessfull_Board) {
//            System.out.println("Unsuccessful Board "+Arrays.toString(i));
//
        }
        return false;

    }


    // Test
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter board size:");
        int n = input.nextInt();
        for (int x = 0; x < n; x++) {
            if( n%2 !=0 || n<2)
            {
                System.out.println("Cannot Solve : entered size is less than 2 or odd .  ");
                break;
            }
            Integer[] Board = new Integer[n];
            Arrays.fill(Board, 1);
            System.out.println("When empty cell at index: " + x);
            Board[x] = 0;
            String integerArr = Arrays.toString(Board);
            System.out.println("Board : " + integerArr);

            DP dp= new DP(Board);
            dp.Solve();


           System.out.println("------------------------");


            // Board will be solved in indicies n-5 ,n-2,1,4
            //remaining peg is in index 1 or n-1


        }
    }
}



