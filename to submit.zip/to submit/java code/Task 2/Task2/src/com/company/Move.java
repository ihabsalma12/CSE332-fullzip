package com.company;

public interface Move {
}
